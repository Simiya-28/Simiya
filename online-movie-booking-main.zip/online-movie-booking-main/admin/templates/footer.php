		<script src="./jquery.min.js"></script>
	<script src="./js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="./feather.min.js"></script>
	<script src="./Chart.min.js"></script>
	<script src="./js/dashboard.js"></script>
 </body>
</html>